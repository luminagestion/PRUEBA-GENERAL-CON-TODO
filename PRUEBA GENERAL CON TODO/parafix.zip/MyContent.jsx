import { useState, useEffect } from 'react'
import { getSession } from '../lib/session.js'

function readJSON(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(raw) return JSON.parse(raw);
  }catch{}
  return fallback;
}

export default function MyContent(){
  const session = getSession();
  const [artists, setArtists] = useState([]);
  const [venues, setVenues] = useState([]);

  useEffect(()=>{
    // Leer artistas: preferir LUMINA_ARTISTS_DB, y mergear con legacy 'artists'
    const a1 = readJSON('LUMINA_ARTISTS_DB', []);
    const a2 = readJSON('artists', []);
    const allArtists = Array.isArray(a1) && a1.length ? a1 : a2;

    const v = readJSON('venues', []);

    const isMine = (item)=>{
      if(!session) return false;
      return (item.ownerId && item.ownerId === session.id) ||
             (item.ownerEmail && item.ownerEmail === session.email);
    };

    setArtists(allArtists.filter(isMine));
    setVenues(v.filter(isMine));
  },[]);

  if(!session){
    return <div style={{margin:'24px auto', maxWidth:900}}>
      <h2>Mis venues y artistas</h2>
      <div className="alert">Iniciá sesión para ver tu contenido.</div>
    </div>
  }

  return (
    <div style={{margin:'24px auto', maxWidth:900, display:'grid', gap:16}}>
      <h2>Mis venues y artistas</h2>

      <section className="card" style={{padding:16}}>
        <h3>Artistas</h3>
        {artists.length===0 ? <div className="muted">No tenés artistas guardados aún.</div> :
          <ul style={{display:'grid', gap:8}}>
            {artists.map(a => (
              <li key={a.id} style={{display:'grid', gap:4}}>
                <strong>{a.name}</strong>
                <div style={{fontSize:13, opacity:0.8}}>{(a.genres||[]).join(', ')}</div>
              </li>
            ))}
          </ul>
        }
      </section>

      <section className="card" style={{padding:16}}>
        <h3>Venues</h3>
        {venues.length===0 ? <div className="muted">No tenés venues guardados aún.</div> :
          <ul style={{display:'grid', gap:8}}>
            {venues.map(v => (
              <li key={v.id} style={{display:'grid', gap:4}}>
                <strong>{v.name}</strong>
                <div style={{fontSize:13, opacity:0.8}}>
                  {v.country || ''} {Number.isFinite(Number(v.capacity)) ? `· Capacidad ${v.capacity}` : ''}
                </div>
              </li>
            ))}
          </ul>
        }
      </section>
    </div>
  );
}
